<?php

namespace Modules\LandingPage\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\LandingPage\Entities\LandingPageSetting;

class PortfolioController extends Controller
{
    public function index()
    {
        if(\Auth::user()->type == 'super admin')
        {
            $settings = LandingPageSetting::landingPageSetting();
            $portfolios = json_decode($settings['portfolios'], true) ?? [];
            return view('landingpage::landingpage.portfolio.index', compact('settings', 'portfolios'));
        }
        else
        {
            return redirect()->back()->with('error', __('Permission denied.'));
        }
    }

    public function create()
    {
        return view('landingpage::landingpage.portfolio.create');
    }

    public function store(Request $request)
    {
        $data['portfolio_status'] = $request->portfolio_status ? $request->portfolio_status : 'off';
        $data['portfolio_title'] = $request->portfolio_title;
        $data['portfolio_heading'] = $request->portfolio_heading;
        $data['portfolio_description'] = $request->portfolio_description;

        foreach($data as $key => $value){
            LandingPageSetting::updateOrCreate(['name' =>  $key],['value' => $value]);
        }

        return redirect()->back()->with(['success'=> __('Setting update successfully')]);
    }

    public function portfolio_create()
    {
        return view('landingpage::landingpage.portfolio.create');
    }

    public function portfolio_store(Request $request)
    {
        $settings = LandingPageSetting::settings();
        $portfolios = json_decode($settings['portfolios'], true) ?? [];

        $data = [];
        $data['category'] = $request->category;
        $data['type'] = $request->type; // image or video
        
        if($request->hasFile('image')){
            $imageName = time()."-portfolio." . $request->image->getClientOriginalExtension();
            $dir = 'uploads/landing_page_image';
            $path = LandingPageSetting::upload_file($request, 'image', $imageName, $dir, []);
            if($path['flag'] == 0){
                return redirect()->back()->with('error', __($path['msg']));
            }
            $data['image'] = $imageName;
        }

        $data['video_url'] = $request->video_url;

        $portfolios[] = $data;
        $portfolios = json_encode($portfolios);
        LandingPageSetting::updateOrCreate(['name' => 'portfolios'], ['value' => $portfolios]);

        return redirect()->back()->with(['success' => __('Portfolio item added successfully')]);
    }

    public function portfolio_edit($key)
    {
        $settings = LandingPageSetting::settings();
        $portfolios = json_decode($settings['portfolios'], true);
        $portfolio = $portfolios[$key];
        return view('landingpage::landingpage.portfolio.edit', compact('portfolio', 'key'));
    }

    public function portfolio_update(Request $request, $key)
    {
        $settings = LandingPageSetting::settings();
        $portfolios = json_decode($settings['portfolios'], true);

        $portfolios[$key]['category'] = $request->category;
        $portfolios[$key]['type'] = $request->type;
        $portfolios[$key]['video_url'] = $request->video_url;

        if($request->hasFile('image')){
            $imageName = time()."-portfolio." . $request->image->getClientOriginalExtension();
            $dir = 'uploads/landing_page_image';
            $path = LandingPageSetting::upload_file($request, 'image', $imageName, $dir, []);
            if($path['flag'] == 0){
                return redirect()->back()->with('error', __($path['msg']));
            }
            $portfolios[$key]['image'] = $imageName;
        }

        $portfolios = json_encode($portfolios);
        LandingPageSetting::updateOrCreate(['name' => 'portfolios'], ['value' => $portfolios]);

        return redirect()->back()->with(['success' => __('Portfolio item updated successfully')]);
    }

    public function portfolio_delete($key)
    {
        $settings = LandingPageSetting::settings();
        $portfolios = json_decode($settings['portfolios'], true);
        unset($portfolios[$key]);
        // Re-index array for JSON
        $portfolios = array_values($portfolios);
        LandingPageSetting::updateOrCreate(['name' => 'portfolios'], ['value' => json_encode($portfolios)]);

        return redirect()->back()->with(['success' => __('Portfolio item deleted successfully')]);
    }
}

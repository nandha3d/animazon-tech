<?php

namespace App\Http\Controllers;

use App\Models\ProjectType;
use App\Models\CostCalculatorQuestion;
use App\Models\CostCalculatorAnswer;
use App\Models\CostEstimate;
use App\Models\CostEstimateAnswer;
use App\Models\User;
use App\Notifications\EstimateSubmittedNotification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class CostCalculatorController extends Controller
{
    /**
     * Currency rates relative to USD (base = 1 USD)
     */
    private const CURRENCY_MAP = [
        'US' => ['code' => 'USD', 'symbol' => '$', 'rate' => 1.00, 'name' => 'US Dollar'],
        'GB' => ['code' => 'GBP', 'symbol' => '£', 'rate' => 0.79, 'name' => 'British Pound'],
        'EU' => ['code' => 'EUR', 'symbol' => '€', 'rate' => 0.92, 'name' => 'Euro'],
        'IN' => ['code' => 'INR', 'symbol' => '₹', 'rate' => 83.50, 'name' => 'Indian Rupee'],
        'AE' => ['code' => 'AED', 'symbol' => 'د.إ', 'rate' => 3.67, 'name' => 'UAE Dirham'],
        'SA' => ['code' => 'SAR', 'symbol' => '﷼', 'rate' => 3.75, 'name' => 'Saudi Riyal'],
        'AU' => ['code' => 'AUD', 'symbol' => 'A$', 'rate' => 1.53, 'name' => 'Australian Dollar'],
        'CA' => ['code' => 'CAD', 'symbol' => 'C$', 'rate' => 1.36, 'name' => 'Canadian Dollar'],
        'JP' => ['code' => 'JPY', 'symbol' => '¥', 'rate' => 151.00, 'name' => 'Japanese Yen'],
        'SG' => ['code' => 'SGD', 'symbol' => 'S$', 'rate' => 1.34, 'name' => 'Singapore Dollar'],
        'MY' => ['code' => 'MYR', 'symbol' => 'RM', 'rate' => 4.72, 'name' => 'Malaysian Ringgit'],
        'DE' => ['code' => 'EUR', 'symbol' => '€', 'rate' => 0.92, 'name' => 'Euro'],
        'FR' => ['code' => 'EUR', 'symbol' => '€', 'rate' => 0.92, 'name' => 'Euro'],
        'IT' => ['code' => 'EUR', 'symbol' => '€', 'rate' => 0.92, 'name' => 'Euro'],
        'ES' => ['code' => 'EUR', 'symbol' => '€', 'rate' => 0.92, 'name' => 'Euro'],
        'NL' => ['code' => 'EUR', 'symbol' => '€', 'rate' => 0.92, 'name' => 'Euro'],
        'CH' => ['code' => 'CHF', 'symbol' => 'Fr', 'rate' => 0.88, 'name' => 'Swiss Franc'],
        'SE' => ['code' => 'SEK', 'symbol' => 'kr', 'rate' => 10.50, 'name' => 'Swedish Krona'],
        'NO' => ['code' => 'NOK', 'symbol' => 'kr', 'rate' => 10.80, 'name' => 'Norwegian Krone'],
        'NZ' => ['code' => 'NZD', 'symbol' => 'NZ$', 'rate' => 1.67, 'name' => 'New Zealand Dollar'],
        'ZA' => ['code' => 'ZAR', 'symbol' => 'R', 'rate' => 18.50, 'name' => 'South African Rand'],
        'BR' => ['code' => 'BRL', 'symbol' => 'R$', 'rate' => 5.05, 'name' => 'Brazilian Real'],
        'MX' => ['code' => 'MXN', 'symbol' => 'MX$', 'rate' => 17.20, 'name' => 'Mexican Peso'],
        'KR' => ['code' => 'KRW', 'symbol' => '₩', 'rate' => 1320.00, 'name' => 'South Korean Won'],
        'CN' => ['code' => 'CNY', 'symbol' => '¥', 'rate' => 7.24, 'name' => 'Chinese Yuan'],
        'HK' => ['code' => 'HKD', 'symbol' => 'HK$', 'rate' => 7.83, 'name' => 'Hong Kong Dollar'],
        'TH' => ['code' => 'THB', 'symbol' => '฿', 'rate' => 35.50, 'name' => 'Thai Baht'],
        'PH' => ['code' => 'PHP', 'symbol' => '₱', 'rate' => 56.20, 'name' => 'Philippine Peso'],
        'EG' => ['code' => 'EGP', 'symbol' => 'E£', 'rate' => 30.90, 'name' => 'Egyptian Pound'],
        'NG' => ['code' => 'NGN', 'symbol' => '₦', 'rate' => 1550.00, 'name' => 'Nigerian Naira'],
        'KE' => ['code' => 'KES', 'symbol' => 'KSh', 'rate' => 153.00, 'name' => 'Kenyan Shilling'],
        'PK' => ['code' => 'PKR', 'symbol' => '₨', 'rate' => 278.00, 'name' => 'Pakistani Rupee'],
        'BD' => ['code' => 'BDT', 'symbol' => '৳', 'rate' => 110.00, 'name' => 'Bangladeshi Taka'],
        'LK' => ['code' => 'LKR', 'symbol' => 'Rs', 'rate' => 310.00, 'name' => 'Sri Lankan Rupee'],
        'QA' => ['code' => 'QAR', 'symbol' => 'QR', 'rate' => 3.64, 'name' => 'Qatari Riyal'],
        'KW' => ['code' => 'KWD', 'symbol' => 'KD', 'rate' => 0.31, 'name' => 'Kuwaiti Dinar'],
        'BH' => ['code' => 'BHD', 'symbol' => 'BD', 'rate' => 0.38, 'name' => 'Bahraini Dinar'],
        'OM' => ['code' => 'OMR', 'symbol' => 'OMR', 'rate' => 0.39, 'name' => 'Omani Rial'],
    ];

    /**
     * Country names for the dropdown
     */
    private const COUNTRIES = [
        'US' => 'United States', 'GB' => 'United Kingdom', 'IN' => 'India',
        'AE' => 'United Arab Emirates', 'SA' => 'Saudi Arabia', 'QA' => 'Qatar',
        'KW' => 'Kuwait', 'BH' => 'Bahrain', 'OM' => 'Oman',
        'AU' => 'Australia', 'CA' => 'Canada', 'NZ' => 'New Zealand',
        'DE' => 'Germany', 'FR' => 'France', 'IT' => 'Italy',
        'ES' => 'Spain', 'NL' => 'Netherlands', 'CH' => 'Switzerland',
        'SE' => 'Sweden', 'NO' => 'Norway',
        'JP' => 'Japan', 'SG' => 'Singapore', 'MY' => 'Malaysia',
        'KR' => 'South Korea', 'CN' => 'China', 'HK' => 'Hong Kong',
        'TH' => 'Thailand', 'PH' => 'Philippines',
        'BR' => 'Brazil', 'MX' => 'Mexico',
        'ZA' => 'South Africa', 'NG' => 'Nigeria', 'KE' => 'Kenya', 'EG' => 'Egypt',
        'PK' => 'Pakistan', 'BD' => 'Bangladesh', 'LK' => 'Sri Lanka',
    ];

    /**
     * Public: Show the project type selection page (categories + sub-services)
     */
    public function publicIndex()
    {
        $categories = ProjectType::whereNull('parent_id')
            ->where('active', true)
            ->with(['children' => function ($q) {
                $q->where('active', true)->orderBy('name');
            }])
            ->orderBy('name')
            ->get();

        $countries = self::COUNTRIES;
        $currencies = self::CURRENCY_MAP;

        return view('cost-calculator.public-index', compact('categories', 'countries', 'currencies'));
    }

    /**
     * Public: Show the calculator wizard for a specific sub-service
     */
    public function publicCalculator($projectTypeId)
    {
        $projectType = ProjectType::with(['parent', 'children' => function($q) {
            $q->where('active', true)->orderBy('name');
        }])->findOrFail($projectTypeId);

        // If it's a category, show the drill-down view of its sub-services
        if ($projectType->isCategory()) {
            $countries = self::COUNTRIES;
            $currencies = self::CURRENCY_MAP;
            return view('cost-calculator.public-category', compact('projectType', 'countries', 'currencies'));
        }

        // Allow custom projects to proceed to the wizard so they see the custom estimation UI
        // Removal of redirect!
        $questions = CostCalculatorQuestion::where('project_type_id', $projectTypeId)
            ->where('active', true)
            ->with(['answers' => function ($q) {
                $q->where('active', true)->orderBy('order');
            }])
            ->orderBy('order')
            ->get();

        // Get sibling services for the nav
        $siblings = ProjectType::where('parent_id', $projectType->parent_id)
            ->where('active', true)
            ->where('base_cost', '>', 0)
            ->orderBy('name')
            ->get();

        $countries = self::COUNTRIES;
        $currencies = self::CURRENCY_MAP;

        return view('cost-calculator.public-calculator', compact(
            'projectType', 'questions', 'siblings', 'countries', 'currencies'
        ));
    }

    /**
     * Public: Calculate cost via AJAX (no auth required)
     */
    public function publicCalculate(Request $request)
    {
        $request->validate([
            'project_type_id' => 'required|exists:project_types,id',
            'answers' => 'required|array',
            'country_code' => 'nullable|string|max:5',
        ]);

        $projectTypeId = $request->input('project_type_id');
        $answers = $request->input('answers', []);
        $countryCode = $request->input('country_code', 'US');

        $projectType = ProjectType::findOrFail($projectTypeId);
        $baseCost = (float)$projectType->base_cost;

        $totalMultiplier = 1.0;
        $additionalCosts = 0;
        $costBreakdown = [];

        foreach ($answers as $questionId => $answer) {
            $question = CostCalculatorQuestion::with(['answers' => function ($q) {
                $q->where('active', true);
            }])->find($questionId);

            if (!$question) continue;

            if ($question->type === 'single_select' || $question->type === 'multi_select') {
                $answerIds = is_array($answer) ? $answer : [$answer];

                foreach ($answerIds as $answerId) {
                    $answerObj = CostCalculatorAnswer::find($answerId);
                    if (!$answerObj) continue;

                    $costBreakdown[] = [
                        'question' => $question->question,
                        'answer' => $answerObj->answer_text,
                        'multiplier' => $answerObj->cost_multiplier,
                        'additional_cost' => $answerObj->additional_cost,
                    ];

                    $totalMultiplier *= (float)$answerObj->cost_multiplier;
                    $additionalCosts += (float)$answerObj->additional_cost;
                }
            } elseif ($question->type === 'input') {
                $val = 0;
                if (is_array($answer)) {
                    $val = floatval($answer['value'] ?? ($answer[0] ?? 0));
                } else {
                    $val = floatval($answer);
                }
                
                if ($val > 0) {
                    $answerObj = $question->answers->first();
                    if ($answerObj) {
                        $costBreakdown[] = [
                            'question' => $question->question,
                            'answer' => $val . ' × ' . $answerObj->answer_text,
                            'multiplier' => $answerObj->cost_multiplier > 0 ? ($answerObj->cost_multiplier * $val) : 1,
                            'additional_cost' => $answerObj->additional_cost * $val,
                        ];

                        if ((float)$answerObj->cost_multiplier > 0) {
                            $totalMultiplier *= ((float)$answerObj->cost_multiplier * $val);
                        }
                        $additionalCosts += ((float)$answerObj->additional_cost * $val);
                    }
                }
            }
        }

        $totalCostUsd = ($baseCost * $totalMultiplier) + $additionalCosts;

        // Convert to local currency
        $currency = self::CURRENCY_MAP[$countryCode] ?? self::CURRENCY_MAP['US'];
        $totalCostLocal = $totalCostUsd * $currency['rate'];
        $baseCostLocal = $baseCost * $currency['rate'];

        // If outside India, calculate charges at 2x the Indian base rate equivalent
        if ($countryCode !== 'IN') {
            $totalCostLocal *= 2;
            $baseCostLocal *= 2;
        }

        // Timeline and team estimation
        $timeline = $this->estimateTimeline($totalCostUsd);
        $teamSize = $this->estimateTeamSize($totalCostUsd);

        return response()->json([
            'success' => true,
            'project_type' => $projectType->name,
            'base_cost_usd' => round($baseCost, 2),
            'base_cost_local' => round($baseCostLocal, 2),
            'total_multiplier' => round($totalMultiplier, 2),
            'additional_costs_usd' => round($additionalCosts, 2),
            'additional_costs_local' => round($additionalCosts * $currency['rate'], 2),
            'total_cost_usd' => round($totalCostUsd, 2),
            'total_cost_local' => round($totalCostLocal, 2),
            'currency' => $currency,
            'timeline_weeks' => $timeline,
            'team_size' => $teamSize,
            'cost_breakdown' => $costBreakdown,
        ]);
    }

    /**
     * Public: Submit estimate with visitor info (lead capture)
     */
    public function publicSubmit(Request $request)
    {
        $request->validate([
            'project_type_id' => 'required|exists:project_types,id',
            'visitor_name' => 'required|string|max:255',
            'visitor_email' => 'required|email|max:255',
            'visitor_phone' => 'nullable|string|max:50',
            'total_cost' => 'required|numeric',
            'grand_total' => 'required|numeric',
            'currency_code' => 'nullable|string|max:5',
            'country_code' => 'nullable|string|max:5',
            'timeline_weeks' => 'nullable|integer',
            'team_size' => 'nullable|integer',
            'notes' => 'nullable|string|max:2000',
            'answers' => 'nullable|array',
            'document' => 'nullable|file|mimes:pdf,doc,docx,zip,jpeg,png,jpg|max:10240',
        ]);

        $projectType = ProjectType::findOrFail($request->project_type_id);
        $countryCode = $request->country_code ?? 'US';
        $currency = self::CURRENCY_MAP[$countryCode] ?? self::CURRENCY_MAP['US'];

        $documentPath = null;
        if ($request->hasFile('document')) {
            $documentPath = $request->file('document')->store('estimates/documents', 'public');
        }

        $estimate = CostEstimate::create([
            'project_type_id' => $request->project_type_id,
            'project_name' => $projectType->name . ' Project - ' . $request->visitor_name,
            'visitor_name' => $request->visitor_name,
            'visitor_email' => $request->visitor_email,
            'visitor_phone' => $request->visitor_phone,
            'base_cost' => $projectType->base_cost,
            'total_cost' => $request->total_cost,
            'tax_percentage' => 0,
            'tax_amount' => 0,
            'grand_total' => $request->grand_total,
            'currency_code' => $currency['code'],
            'timeline_weeks' => $request->timeline_weeks,
            'team_size' => $request->team_size,
            'notes' => $request->notes,
            'document_path' => $documentPath,
            'status' => 'draft',
        ]);

        // Store answers
        if (!empty($request->answers) && is_array($request->answers)) {
            foreach ($request->answers as $questionId => $answer) {
                $question = CostCalculatorQuestion::find($questionId);
                if (!$question) continue;

                if ($question->type === 'single_select' || $question->type === 'multi_select') {
                    $answerIds = is_array($answer) ? $answer : [$answer];
                    foreach ($answerIds as $answerId) {
                    $answerObj = CostCalculatorAnswer::find($answerId);
                    if (!$answerObj) continue;

                    CostEstimateAnswer::create([
                        'cost_estimate_id' => $estimate->id,
                        'question_id' => $questionId,
                        'answer_id' => $answerId,
                        'cost_contribution' => ($estimate->base_cost * $answerObj->cost_multiplier) + $answerObj->additional_cost,
                    ]);
                }
            } else {
                CostEstimateAnswer::create([
                    'cost_estimate_id' => $estimate->id,
                    'question_id' => $questionId,
                    'answer_value' => $answer,
                ]);
            }
            }
        }

        // Send notification to admin
        try {
            $admin = User::where('type', 'super admin')->first();
            if ($admin) {
                $admin->notify(new EstimateSubmittedNotification($estimate));
            }
        } catch (\Exception $e) {
            Log::warning('Estimate notification failed: ' . $e->getMessage());
        }

        return response()->json([
            'success' => true,
            'message' => 'Thank you! Your estimate has been submitted. We\'ll contact you shortly.',
            'estimate_id' => $estimate->id,
        ]);
    }

    /**
     * API: Get currency info for a country code
     */
    public function getCurrency(Request $request)
    {
        $countryCode = $request->input('country_code', 'US');
        $currency = self::CURRENCY_MAP[$countryCode] ?? self::CURRENCY_MAP['US'];

        return response()->json([
            'success' => true,
            'currency' => $currency,
            'country_code' => $countryCode,
        ]);
    }

    // ─── Private Helpers ────────────────────────────────────────

    private function estimateTimeline($costUsd)
    {
        if ($costUsd <= 3000) return 2;
        if ($costUsd <= 5000) return 4;
        if ($costUsd <= 10000) return 6;
        if ($costUsd <= 20000) return 10;
        if ($costUsd <= 50000) return 16;
        return max(1, ceil($costUsd / 3000));
    }

    private function estimateTeamSize($costUsd)
    {
        if ($costUsd <= 3000) return 2;
        if ($costUsd <= 8000) return 3;
        if ($costUsd <= 15000) return 4;
        if ($costUsd <= 30000) return 6;
        return max(1, ceil($costUsd / 5000));
    }
}
